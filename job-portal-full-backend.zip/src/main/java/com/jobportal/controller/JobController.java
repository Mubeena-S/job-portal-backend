package com.jobportal.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/jobs")
public class JobController {

    @GetMapping
    public String listJobs() {
        return "List of Jobs";
    }
}